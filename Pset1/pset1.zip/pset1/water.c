#include <stdio.h>
#include <cs50.h>
//declare two variable
int minutes;
int bottles;
//declare main function
int main (void)
{
do
{
    printf("How many minutes have you been in the shower:\n");
    minutes=get_int();
    //declare variable calculate bottles
    bottles=(minutes*12);
        if (minutes >= 10)
        {
            printf("Minutes: %i\n", minutes);
            printf("Bottles: %i\n", bottles);
            printf ("You consume too much water :-)\n");
        }
        else if (minutes >= 0)
        {
            printf("Minutes: %i\n", minutes);
            printf("Bottles: %i\n", bottles);
        }
        else
        {
            printf("Please enter a positive number:\n");
        }
} while (minutes<0);

}

